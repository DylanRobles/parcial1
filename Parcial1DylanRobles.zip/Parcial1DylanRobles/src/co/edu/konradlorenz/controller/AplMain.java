package co.edu.konradlorenz.controller;

public class AplMain {

	public static void main(String[] args) {
		Controlador objCo = new Controlador();
		objCo.run();
	}

}
