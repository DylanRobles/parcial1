package co.edu.konradlorenz.model;

import java.util.ArrayList;

public class ListaJugadores {
	
	private ArrayList<Jugador> listaJugadores = new ArrayList<>();
	
	Jugador objJu = new Jugador();

	public Jugador getObjJu() {
		return objJu;
	}

	public void setObjJu(Jugador objJu) {
		this.objJu = objJu;
	}
	
	public void agregarJugador(Jugador jugador) {
		
	listaJugadores.add(objJu);
		
		
	}
	
	public  Jugador mostrarLista() {
		
		for(int i = 0; i<listaJugadores.size(); i++ ) {
			
			return listaJugadores.get(i);
			
		}
	
	return null;
	}
	
	

}
