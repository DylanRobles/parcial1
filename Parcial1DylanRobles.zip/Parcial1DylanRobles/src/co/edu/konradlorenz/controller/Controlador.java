package co.edu.konradlorenz.controller;

import co.edu.konradlorenz.model.Jugador;
import co.edu.konradlorenz.model.ListaJugadores;
import co.edu.konradlorenz.view.Vista;

public class Controlador {
	
	
	Jugador objJu = new Jugador();
	Vista  objVi = new Vista();
	ListaJugadores objLi = new ListaJugadores();
	
	public void run() {
		int opcion = objVi.pedirInt("indique el menu al que quiere entrar");
		do {
		switch(opcion) {
		
		
		case 1:
			
			crearJugador();
			agregarLista();
			
			
			break;
			
		case 2:
			
			mostrarLista();
			
			
			break;
			
		case 3:
			
			break;
			
		case 4:
		
		break;
		
		}
		
		
		}while(opcion != 5);
		
	}
	
	public void crearJugador() {
		
		objJu.setNombre(objVi.pedirString("Ingrese el nombre del jugador"));
		objJu.setEstado(objVi.pedirvalor("Ingrese si el jugador esta retirado"));
		
		
		
		if(objJu.getEstado() == true) {
			objJu.setAnnoRetiro(objVi.pedirString("ingrese el año de retiro del jugador"));
			
			
		
		}else {
			objJu.setAnnoRetiro(null);
			
		}
		objJu.setBalonOro(objVi.pedirString("ingrese si el jugador a conseguido balones de oro"));
		
		
		objJu.setPosicion(objVi.pedirInt("ingrese la posicion del jugador"));
		objJu.setClub(objVi.pedirString("ingrese ultimo club al que el jugador pertenecio"));
		
		objVi.mostrarString(objJu.toString());
		
		
	}
	
	public void agregarLista() {
		objLi.agregarJugador(objJu);
		
	}
	
	public void mostrarLista() {
		
		
	}
	



}
